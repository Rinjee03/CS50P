from fpdf import FPDF

# Define a class that extends FPDF to customize the header and footer
class PDF(FPDF):
    # This method adds a header at the top of the page
    def header(self):
        # Set font for the header
        self.set_font('Arial', 'B', 16)
        # Add a centered title "CS50 Shirtificate"
        self.cell(200, 10, 'CS50 Shirtificate', ln=True, align='C')

    # This method adds a footer at the bottom of the page
    def footer(self):
        # Set position for the footer
        self.set_y(-15)
        # Set font for the footer
        self.set_font('Arial', 'I', 8)
        # Add page number in the center of the footer
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

# Function to create the shirtificate PDF
def create_shirtificate(name):
    # Create a new PDF object
    pdf = PDF()
    # Set the PDF to automatically break pages when needed
    pdf.set_auto_page_break(auto=True, margin=15)
    # Add a new page to the PDF
    pdf.add_page()

    # Add the shirt image centered horizontally
    # (The shirt image will be placed at the center of the page, width of 140mm)
    pdf.image("shirtificate.png", x=(pdf.w - 140) / 2, y=50, w=140)

    # Set text color to white (for the name on the shirt)
    pdf.set_text_color(255, 255, 255)
    # Set font for the name on the shirt
    pdf.set_font('Arial', 'B', 24)

    # Move the cursor down to make space above the shirt
    pdf.ln(100)  # This is to ensure the name is placed above the shirt image
    # Add the user's name, centered horizontally
    pdf.cell(200, 10, name, ln=True, align='C')

    # Save the PDF to a file called 'shirtificate.pdf'
    pdf.output("shirtificate.pdf")

# Main function to prompt the user for their name and create the shirtificate
def main():
    # Ask the user for their name
    name = input("Enter your name: ")

    # Call the function to create the shirtificate with the entered name
    create_shirtificate(name)
    # Print a message to tell the user the PDF was created successfully
    print("Shirtificate created successfully! Check the 'shirtificate.pdf' file.")

# This ensures the main function runs only if the script is run directly (not imported)
if __name__ == "__main__":
    main()
