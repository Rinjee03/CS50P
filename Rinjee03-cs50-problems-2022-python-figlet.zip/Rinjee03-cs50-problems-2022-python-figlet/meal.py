def main():
    t= input("What time is it? : ")
    #calling function called convert
    food = convert(t)

    if 7<= food <=8:
        print("breakfast time")

    elif 12<= food <=13:
        print("lunch time")

    elif 18<= food <=19:
        print("dinner time")

    else:
        print()



def convert(time):
    #spliting string into hrs and min
    hrs,min = time.split(":")
    #converting min into float and then min into hours
    n_min = float(min)/60
    n_time = n_min + float(hrs)
    return n_time


if __name__ == "__main__":
     main()
