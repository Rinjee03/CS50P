from plates import is_valid

# Test function to check plate length bounds
def test_bounds():
    # Too short
    assert is_valid("A") == False
    # Minimum valid length
    assert is_valid("AB") == True
    # Too long
    assert is_valid("ABCDEFG") == False

# Test function to check for special characters
def test_special_chars():
    # Only special characters
    assert is_valid("@#$") == False
    # Contains spaces
    assert is_valid(" CS50 ") == False
    # Contains invalid symbols
    assert is_valid("PI3.14") == False

# Test function to check placement of numbers
def test_numbers_placement():
    # Numbers at the start
    assert is_valid("50CS") == False
    # Only numbers
    assert is_valid("123456") == False
    # Valid placement of numbers
    assert is_valid("ABC123") == True
    # Letters after numbers
    assert is_valid("ABC12D") == False

# Test function to check rules about zero placement
def test_zero_placement():
    # Valid use of numbers without leading zero
    assert is_valid("CS50") == True
    # Invalid use of numbers with leading zero
    assert is_valid("CS05") == False
