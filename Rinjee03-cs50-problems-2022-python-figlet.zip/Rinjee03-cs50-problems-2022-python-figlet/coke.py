amount_due = 50

#loop until the amount due is greater than 0
while amount_due > 0:
    print("Amount Due:",amount_due)
    #asking consumer to insert coin
    coin = int(input("Insert coin: "))
    #checking if the coin match with the list or not
    if coin in [25,10,5]:
        #subracting coin from the amount due
        amount_due -= coin

#after the loop break, give the change
changed_own = abs(amount_due)

print("Changed Owed:",changed_own)


