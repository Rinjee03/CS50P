import re
import sys

def main():
    # Prompt the user to input an IPv4 address
    print(validate(input("IPv4 Address: ")))

def validate(ip):
    # Define a pattern to match a valid IPv4 address
    # An IPv4 address must have four numbers separated by dots (e.g., 192.168.1.1)
    # Each number must be between 0 and 255
    pattern = r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$"

    # Check if the input matches the pattern
    match = re.match(pattern, ip)
    if match:
        # Extract the four parts of the IP address
        parts = match.groups()

        # Check if all parts are valid numbers between 0 and 255
        for part in parts:
            # Convert the part to an integer and ensure it's in the valid range
            if not (0 <= int(part) <= 255):
                return False
        return True  # All parts are valid

    # If the pattern doesn't match, it's not a valid IPv4 address
    return False

if __name__ == "__main__":
    main()
