import random

def main():
    level = get_level()  # Get level from user
    score = 0  # Initialize score

    # Loop through 10 problems
    for i in range(1, 11):
        # Generate two random integers based on level
        x = generate_integer(level)
        y = generate_integer(level)

        correct_answer = x + y  # Calculate the correct answer
        tries = 0  # Number of attempts made by user

        while tries < 3:
            # Prompt the user for their answer
            user_answer = input(f"Problem {i}: {x} + {y} = ")

            # Check if the input is a valid integer
            try:
                if int(user_answer) == correct_answer:
                    score += 1  # Correct answer, increment score
                    break  # Exit the while loop as the answer is correct
                else:
                    print("EEE")  # Incorrect answer
                    tries += 1  # Increment the number of tries
            except ValueError:
                print("EEE")  # Invalid input (not a number)
                tries += 1  # Increment the number of tries

        # If 3 incorrect answers are given, show the correct answer
        if tries == 3:
            print(f"The correct answer is {correct_answer}")

    # Output the final score after 10 problems
    print(f"Your score is {score} out of 10.")

def get_level():
    """Prompts the user to enter a level between 1, 2, and 3."""
    while True:
        try:
            level = int(input("Enter the level (1, 2, or 3): "))
            if level in [1, 2, 3]:
                return level  # Valid level input
            else:
                print("Please enter 1, 2, or 3.")
        except ValueError:
            print("Invalid input. Please enter 1, 2, or 3.")

def generate_integer(level):
    """Generates a random integer based on the level."""
    # Depending on the level, the number of digits is set
    if level == 1:
        return random.randint(0, 9)  # Single digit number
    elif level == 2:
        return random.randint(10, 99)  # Two digit number
    elif level == 3:
        return random.randint(100, 999)  # Three digit number
    else:
        raise ValueError("Level must be 1, 2, or 3.")

if __name__ == "__main__":
    main()
