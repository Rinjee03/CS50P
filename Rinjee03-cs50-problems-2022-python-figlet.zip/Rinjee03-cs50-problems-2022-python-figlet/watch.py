import re
import sys

def main():
    # Prompt the user for HTML input
    print(parse(input("HTML: ")))

def parse(s):
    # Define a pattern to extract YouTube embed URLs
    pattern = r'src="(https?://(?:www\.)?youtube\.com/embed/([a-zA-Z0-9_-]+))"'

    # Search for the pattern in the input string
    match = re.search(pattern, s)
    if match:
        # If a match is found, extract the video ID and return the shortened URL
        video_id = match.group(2)
        return f"https://youtu.be/{video_id}"

    # If no match is found, return None
    return None

if __name__ == "__main__":
    main()
