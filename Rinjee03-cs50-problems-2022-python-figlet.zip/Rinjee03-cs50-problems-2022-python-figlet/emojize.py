import emoji

emojies = input("Input : ")

#The language='alias' tells emoji.emojize() to interpret aliases such as :smile: as actual emojis (😊).
output = emoji.emojize(emojies, language='alias')

print("Output :", output)
