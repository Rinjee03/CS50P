#ask user to write something

write = input("please write something\n").lower()

print(write)
