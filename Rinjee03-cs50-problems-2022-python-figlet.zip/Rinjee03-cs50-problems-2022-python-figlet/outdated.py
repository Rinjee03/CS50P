# List of months for reference
months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

while True:
    # Prompt user to enter a date
    date = input("Date: ").strip()

    try:
        # Check for MM/DD/YYYY format
        if "/" in date:
            month, day, year = date.split("/")
            month = int(month)
            day = int(day)
            year = int(year)

            # Validate the month and day
            if 1 <= month <= 12 and 1 <= day <= 31:
                print(f"{year:04}-{month:02}-{day:02}")
                break  # Exit loop if input is valid

        # Check for "Month DD, YYYY" format
        elif "," in date:
            o_month, o_day_year = date.split(" ", 1)
            o_day, year = o_day_year.split(",")
            o_day = int(o_day.strip())
            year = int(year.strip())

            # Convert month name to a number
            for i in range(len(months)):
                if o_month == months[i]:
                    month = i + 1
                    break
            else:
                raise ValueError  # If month name is invalid, raise error

            # Validate the month and day
            if 1 <= month <= 12 and 1 <= o_day <= 31:
                print(f"{year:04}-{month:02}-{o_day:02}")
                break  # Exit loop if input is valid

    except:
        # Handle any errors (e.g., invalid input format, conversion issues)
        print("Invalid date. Please try again.")
