import pytest
from um import count


def test_single_um():
    # Test a single occurrence of "um"
    assert count("um") == 1
    assert count("Um") == 1
    assert count("UM") == 1


def test_multiple_ums():
    # Test multiple occurrences of "um"
    assert count("um, um, um.") == 3
    assert count("Um? um! UM.") == 3
    assert count("hello um world um") == 2


def test_no_ums():
    # Test cases where "um" doesn't appear as a standalone word
    assert count("yummy") == 0
    assert count("umbrella") == 0
    assert count("drum") == 0


def test_edge_cases():
    # Test edge cases, such as "um" at the beginning or end of the text
    assert count("um... hello") == 1
    assert count("hello... um") == 1
    assert count("...um...") == 1
    assert count("... um ...") == 1
