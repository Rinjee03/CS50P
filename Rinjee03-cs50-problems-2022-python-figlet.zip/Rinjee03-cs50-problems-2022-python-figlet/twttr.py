def main():
    write = input("Input : ")
    no_vowels_words = shorten(write)
    print("Output : " + no_vowels_words)



def shorten(word):
    no_vowels = ""
    for letter in word:
    #checking if a character in letter is not a vowel
        if  not letter.lower() in ["a","e","i","o","u" ] :
            no_vowels += letter
    return no_vowels



if __name__ == "__main__":
    main()
