# project.py

# Function to clear the tasks file before starting (to avoid previous tasks)
def clear_file():
    # Open the tasks.txt file in write mode to clear its content
    with open("tasks.txt", "w") as file:
        file.truncate(0)  # Truncate the file to remove all content
    print("Tasks file cleared.\n")

# This function adds a task to the tasks file
def add_task():
    # Ask the user to enter a task
    task = input("Enter task: ")

    # Open the tasks.txt file in append mode to add the new task at the end
    with open("tasks.txt", "a") as file:
        # Write the task followed by a new line
        file.write(task + "\n")

    # Display the current content of the file for debugging
    with open("tasks.txt", "r") as file:
        print("\nCurrent tasks in file:")
        print(file.read())  # Show the tasks currently stored in the file

    # Let the user know that the task has been added
    print("Task added!\n")

# This function removes a task from the tasks file
def remove_task():
    # Ask the user to enter the task they want to remove
    task = input("Enter task to remove: ")

    # Open the tasks.txt file in read mode to check existing tasks
    with open("tasks.txt", "r") as file:
        # Read all tasks from the file
        tasks = file.readlines()

    # Open the tasks.txt file in write mode to overwrite the content
    with open("tasks.txt", "w") as file:
        # Loop through each task in the file
        for line in tasks:
            # If the task is not the one the user wants to remove, write it back to the file
            if line.strip() != task:
                file.write(line)

    # Let the user know that the task has been removed
    print("Task removed!\n")

# This function lists all the tasks from the tasks file
def list_tasks():
    # Open the tasks.txt file in read mode to get all tasks
    with open("tasks.txt", "r") as file:
        # Read all tasks from the file
        tasks = file.readlines()

    print("Your tasks:")
    # Check if there are no tasks
    if not tasks:
        print("No tasks found.")
    else:
        for task in tasks:
            # Print each task after stripping extra newlines
            print(task.strip())

# Main function to display the menu and run the program
def main():
    clear_file()  # Clear the file at the start of the program

    # Keep the program running until the user chooses to exit
    while True:
        # Display the menu options to the user
        print("\n1. Add Task")
        print("2. Remove Task")
        print("3. List Tasks")
        print("4. Exit")

        # Ask the user to choose an option
        choice = input("Choose an option: ")

        # Based on the user's choice, call the corresponding function
        if choice == "1":
            add_task()  # Add a task
        elif choice == "2":
            remove_task()  # Remove a task
        elif choice == "3":
            list_tasks()  # List all tasks
        elif choice == "4":
            print("Goodbye!")  # Exit the program
            break  # Stop the loop and end the program
        else:
            # If the user enters an invalid option, ask them to try again
            print("Invalid option. Please try again.")

# Check if the script is being run directly (not imported as a module)
if __name__ == "__main__":
    # Call the main function to start the program
    main()
