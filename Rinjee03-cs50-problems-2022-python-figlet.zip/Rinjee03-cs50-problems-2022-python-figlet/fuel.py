# Main function to get user input, convert the fraction to percentage, and print the fuel gauge.
def main():
    while True:
        try:
            # Asking user to input fuel in X/Y format.
            fuel = input("Fraction: ")
            percentage = convert(fuel)
            print(gauge(percentage))
            break
        except (ValueError, ZeroDivisionError):
            pass

# Function to convert a fraction in X/Y format to a percentage.
def convert(fraction):
    try:
        x, y = map(int, fraction.split("/"))
        if y == 0:
            raise ZeroDivisionError("Denominator cannot be zero.")
        if x > y:
            raise ValueError("Numerator cannot be greater than denominator.")
        percentage = round((x / y) * 100)
        return percentage
    except ValueError:
        raise ValueError("Invalid input format. Expected X/Y where X and Y are integers.")

# Function to return the fuel gauge reading based on the percentage.
def gauge(percentage):
    if percentage <= 1:
        return "E"
    elif percentage >= 99:
        return "F"
    else:
        return f"{percentage}%"

if __name__ == "__main__":
    main()




