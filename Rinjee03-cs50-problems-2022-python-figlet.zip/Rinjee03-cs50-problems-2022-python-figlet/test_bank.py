from bank import value

def test_return_zero():
    assert value("hello") == 0
    assert value("hello,ram") == 0


def test_return_twenty():
    assert value("hey") == 20
    assert value("hi, Rinjee") == 20

def test_return_hundred():
    assert value("Rinjee") == 100
    assert value("goodbye") == 100
