from twttr import shorten

def test_uppercase():
    assert shorten("TWITTER") == "TWTTR"
    assert shorten("MONKEY") == "MNKY"

def test_lower():
    assert shorten("hello") == "hll"
    assert shorten("truth") == "trth"

def test_random():
    assert shorten("RinjEE") == "Rnj"

def test_numb():
    assert shorten("1234") == "1234"

def test_punctuation():
    assert shorten("/.,?") == "/.,?"
