def main():
    txt = input("Happy or Sad ? \n")
    #calling convert function and passing argument txt also
    print(convert(txt))



#create convert function
def convert(txt):
    #converting happy faces
    txt1 = txt.replace(":)",'🙂')
    #converting sad faces
    txt2 = txt1.replace(":(",'🙁')
    return txt2


main()


