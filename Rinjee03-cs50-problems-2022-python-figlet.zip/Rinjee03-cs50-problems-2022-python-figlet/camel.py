#ask user to input name in camel case

name = input("camelCase : ")

print("snakeCase : ",end = "")


#ittirate over the name variable
for upperword in name:
    #check if the upper letter is in name
    if upperword.isupper():
        #replace the upperword with " _ "
        print("_" + upperword.lower() , end = "")

    else:
        print(upperword, end = "")

print()





