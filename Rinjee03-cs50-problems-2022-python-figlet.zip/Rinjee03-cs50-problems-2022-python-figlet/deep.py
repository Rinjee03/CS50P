#asking user to answer the question

q = input("What is the answer to the Great Question of Life, the Universe and the Everything : ")

#comparing answer and removing extra from front and end with strip function
if q.strip() == "42" or q.strip() == "forty two"  or q.strip() == "forty-two":
    print("Yes")

#making the input case sensitive so that we can same ouput
elif q.lower().strip()== "forty two":
    print("yes")
else:
    print("No")
