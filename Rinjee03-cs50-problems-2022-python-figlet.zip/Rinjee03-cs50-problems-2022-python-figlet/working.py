import re
import sys


def main():
    # Get user input and call the convert function to process it
    print(convert(input("Hours: ")))


def convert(s):
    """
    Converts a time range in 12-hour format (with AM/PM) to 24-hour format.
    Example input: "9:00 AM to 5:00 PM"
    Example output: "09:00 to 17:00"
    """
    # Regular expression to match the allowed formats
    pattern = r"^(\d{1,2})(?::(\d{2}))? (AM|PM) to (\d{1,2})(?::(\d{2}))? (AM|PM)$"
    match = re.search(pattern, s)

    # If the input doesn't match the pattern, raise an error
    if not match:
        raise ValueError("Invalid time format")

    # Extract the parts of the time from the input
    # Example: "9:00 AM to 5:00 PM" -> start_hour=9, start_minute=00, start_period=AM, etc.
    start_hour, start_minute, start_period, end_hour, end_minute, end_period = match.groups()

    # If minutes are not provided, default to 0 (e.g., "9 AM" becomes "9:00 AM")
    start_minute = int(start_minute) if start_minute else 0
    end_minute = int(end_minute) if end_minute else 0

    # Convert hour strings to integers
    start_hour = int(start_hour)
    end_hour = int(end_hour)

    # Validate that the hours and minutes are within proper ranges
    if not (1 <= start_hour <= 12) or not (0 <= start_minute < 60):
        raise ValueError("Invalid start time")
    if not (1 <= end_hour <= 12) or not (0 <= end_minute < 60):
        raise ValueError("Invalid end time")

    # Convert the start and end times to 24-hour format
    start_hour = convert_to_24_hour(start_hour, start_period)
    end_hour = convert_to_24_hour(end_hour, end_period)

    # Format the result as "HH:MM to HH:MM"
    return f"{start_hour:02}:{start_minute:02} to {end_hour:02}:{end_minute:02}"


def convert_to_24_hour(hour, period):
    """
    Converts an hour in 12-hour format to 24-hour format.
    Example: 9 AM -> 9, 9 PM -> 21, 12 AM -> 0, 12 PM -> 12
    """
    if period == "PM" and hour != 12:
        # For PM times (except 12 PM), add 12 to convert to 24-hour format
        return hour + 12
    if period == "AM" and hour == 12:
        # For 12 AM (midnight), convert to 0
        return 0
    # For all other cases, return the hour as is
    return hour


if __name__ == "__main__":
    main()

