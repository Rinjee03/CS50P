ask = input("Write something \n").replace(" ","...")

print(ask)


