import pytest
from fuel import convert, gauge

# Test cases for the convert function.
def test_convert():
    # Valid inputs
    assert convert("1/2") == 50
    assert convert("0/1") == 0
    assert convert("1/1") == 100

    # Invalid inputs
    with pytest.raises(ValueError):
        convert("2/1")  # Numerator greater than denominator
    with pytest.raises(ZeroDivisionError):
        convert("1/0")  # Denominator is zero
    with pytest.raises(ValueError):
        convert("a/b")  # Non-integer values

# Test cases for the gauge function.
def test_gauge():
    # Edge cases
    assert gauge(0) == "E"
    assert gauge(1) == "E"
    assert gauge(99) == "F"
    assert gauge(100) == "F"

    # Intermediate values
    assert gauge(50) == "50%"
    assert gauge(75) == "75%"
