import sys  # To handle command-line arguments and exit the program
import random  # To randomly choose a font if no font is specified
from pyfiglet import Figlet  # To use the pyfiglet library for generating ASCII art text

# Function to handle the program's logic
def main():
    # Check the number of arguments passed when running the script
    if len(sys.argv) == 1:
        # If no font is specified, choose a random font
        figlet = Figlet()  # Create a Figlet object to work with fonts
        available_fonts = figlet.getFonts()  # Get the list of available fonts
        random_font = random.choice(available_fonts)  # Choose a random font from the list
        figlet.setFont(font=random_font)  # Set the random font
    elif len(sys.argv) == 3:
        # If two arguments are provided, the first should be -f or --font, the second should be a font name
        if sys.argv[1] not in ['-f', '--font']:
            # If the first argument is not -f or --font, show an error and exit
            sys.exit("Error: First argument must be -f or --font.")

        font_name = sys.argv[2]  # Get the font name from the second argument
        figlet = Figlet(font=font_name)  # Try to create a Figlet object with the specified font

        # Check if the font provided is a valid font
        if font_name not in figlet.getFonts():
            # If the font is not valid, show an error and exit
            sys.exit(f"Error: '{font_name}' is not a valid font.")
    else:
        # If there are more or fewer than 1 or 2 arguments, show usage instructions and exit
        sys.exit("Usage: python figlet.py [-f | --font] <font_name>")

    # Ask the user to input a string of text to convert to ASCII art
    text = input("Enter text to display: ")

    # Render and print the text in the selected font
    print(figlet.renderText(text))  # Render the text as ASCII art and print it

# Run the main function when the script is executed
if __name__ == "__main__":
    main()
