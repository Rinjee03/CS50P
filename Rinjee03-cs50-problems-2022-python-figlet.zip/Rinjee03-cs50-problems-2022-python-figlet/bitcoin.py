import sys
import requests

# Check if the user has provided a number of Bitcoins as a command-line argument
if len(sys.argv) != 2:
    print("Usage: python bitcoin.py <number_of_bitcoins>")
    sys.exit(1)

try:
    # Convert the command-line argument to a float representing the number of Bitcoins
    bitcoins = float(sys.argv[1])
except ValueError:
    # If the argument cannot be converted to a float, exit with an error message
    print("Error: Please provide a valid number for the amount of Bitcoins.")
    sys.exit(1)

try:
    # Make a request to the CoinDesk API to get the current Bitcoin price in USD
    response = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
    # Raise an exception if the request failed
    response.raise_for_status()

    # Parse the JSON response
    data = response.json()
    # Get the current Bitcoin price in USD (rate_float)
    bitcoin_price_usd = data['bpi']['USD']['rate_float']
except requests.RequestException:
    # Catch any exception related to the request and display an error message
    print("Error: Could not retrieve Bitcoin price from CoinDesk API.")
    sys.exit(1)

# Calculate the total cost of the specified number of Bitcoins
total_cost = bitcoins * bitcoin_price_usd

# Print the total cost in USD, formatted to four decimal places and with a thousands separator
print(f"Total cost for {bitcoins} Bitcoin(s): ${total_cost:,.4f}")

