
import sys
import csv
from tabulate import tabulate

# Check if there is exactly one command-line argument
if len(sys.argv) != 2:
    print("Usage: python pizza.py filename.csv")
    sys.exit(1)

# Get the file path from the command-line argument
file_path = sys.argv[1]

# Check if the file has a .csv extension
if not file_path.endswith(".csv"):
    print("Error: The file must have a .csv extension.")
    sys.exit(1)

try:
    # Read the CSV file
    with open(file_path, 'r') as file:
        reader = csv.reader(file)

        # Get the header and rows from the CSV
        headers = next(reader)  # First line is the header
        rows = [row for row in reader]  # Remaining lines are the rows

        # Format the table as ASCII art
        table = tabulate(rows, headers=headers, tablefmt="grid")
        print(table)

except FileNotFoundError:
    print(f"Error: The file '{file_path}' does not exist.")
    sys.exit(1)
