def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")

def is_valid(s):
    """
    Validates a vanity plate based on specific rules:
    1. Length must be between 2 and 6 characters.
    2. Must start with at least two letters.
    3. Numbers cannot start with 0 and must be at the end if present.
    4. No special characters or spaces allowed.
    """
    # Check length
    if len(s) < 2 or len(s) > 6:
        return False

    # Check if the first two characters are letters
    if not s[0].isalpha() or not s[1].isalpha():
        return False

    # Check for invalid characters and numeric rules
    number_started = False  # Tracks if numbers have started
    for i, char in enumerate(s):
        if char.isdigit():
            # If a number starts, ensure it doesn't start with 0
            if not number_started and char == "0":
                return False
            number_started = True
        elif number_started:
            # Letters cannot appear after numbers start
            return False
        elif not char.isalpha():
            # Invalid character detected
            return False

    # Check for special characters or spaces
    for char in s:
        if char in [".", "?", " ", "!"]:
            return False

    return True

if __name__ == "__main__":
    main()
