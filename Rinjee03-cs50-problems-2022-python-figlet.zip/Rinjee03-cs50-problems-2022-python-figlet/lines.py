import sys

# Check if there is exactly one command-line argument
if len(sys.argv) != 2:
    print("Usage: python lines.py filename.py")
    sys.exit(1)

# Get the file path from the command-line argument
file_path = sys.argv[1]

# Check if the file has a .py extension
if not file_path.endswith(".py"):
    print("Error: The file must have a .py extension.")
    sys.exit(1)

try:
    with open(file_path, 'r') as file:
        code_lines = 0
        for line in file:
            # Strip the line of leading whitespaces
            stripped_line = line.lstrip()

            # Check if the line is a comment or blank
            if stripped_line.startswith("#") or not stripped_line:
                continue

            # If the line is neither a comment nor blank, count it as a line of code
            code_lines += 1

        # Output the number of lines of code
        print(code_lines)

except FileNotFoundError:
    print(f"Error: The file '{file_path}' does not exist.")
    sys.exit(1)
