import random  # Import the random module to generate random numbers

# Loop to ask for a valid level
while True:
    try:
        level = int(input("Level : "))  # Ask user for the level (maximum number)
        if level > 0:  # Check if level is a positive number
            break  # Exit the loop if the level is valid
    except ValueError:  # Catch non-numeric input
        print("Invalid input. Please enter a valid number.")

number = random.randint(1, level)  # Generate a random number between 1 and the chosen level

# Loop for the guessing game
while True:
    try:
        guess = int(input("Guess : "))  # Ask user to guess the number
        if guess > 0:  # Check if guess is positive
            if guess < number:  # If guess is too small
                print("Too small!")
            elif guess > number:  # If guess is too large
                print("Too large!")
            else:  # If guess is correct
                print("Just right!")
                break  # Exit the loop if the guess is correct
    except ValueError:  # Catch non-numeric input
        print("Invalid input. Please enter a valid number.")
