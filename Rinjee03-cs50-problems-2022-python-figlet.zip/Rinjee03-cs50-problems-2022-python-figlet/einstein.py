m = int(input("Write the value of m : "))
c = 300000000


print("E =",m*pow(c,2))

