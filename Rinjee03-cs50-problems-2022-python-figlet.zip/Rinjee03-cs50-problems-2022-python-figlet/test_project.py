# test_project.py

import os
import pytest
from project import add_task, remove_task, list_tasks, clear_file

# Path to the tasks file
TASKS_FILE = "tasks.txt"

# Helper function to clear and reset the tasks file for each test
def reset_file():
    with open(TASKS_FILE, "w") as file:
        file.truncate(0)  # Clear the file before each test

# Test for the add_task() function
def test_add_task():
    reset_file()  # Ensure the file is empty before the test

    # Test adding a task
    task = "Buy groceries"
    add_task()  # The function will prompt for the task
    with open(TASKS_FILE, "r") as file:
        tasks = file.readlines()

    # Check if the task is written to the file
    assert len(tasks) == 1  # There should be one task in the file
    assert tasks[0].strip() == task  # Check that the task matches the added task

# Test for the remove_task() function
def test_remove_task():
    reset_file()  # Ensure the file is empty before the test

    # Add tasks to remove
    with open(TASKS_FILE, "a") as file:
        file.write("Buy groceries\n")
        file.write("Clean the house\n")

    # Now remove a task
    remove_task()  # The function will prompt for the task to remove
    with open(TASKS_FILE, "r") as file:
        tasks = file.readlines()

    # Check if the task is removed
    assert len(tasks) == 1  # There should be one task left in the file
    assert tasks[0].strip() == "Clean the house"  # "Buy groceries" should be removed

# Test for the list_tasks() function
def test_list_tasks():
    reset_file()  # Ensure the file is empty before the test

    # Add some tasks to list
    with open(TASKS_FILE, "a") as file:
        file.write("Buy groceries\n")
        file.write("Clean the house\n")

    # Capture the output of the list_tasks function using pytest's capsys fixture
    from io import StringIO
    import sys

    captured_output = StringIO()
    sys.stdout = captured_output  # Redirect stdout to capture printed output
    list_tasks()

    # Now check if the output contains the correct tasks
    sys.stdout = sys.__stdout__  # Reset stdout
    output = captured_output.getvalue()

    assert "Your tasks:" in output
    assert "Buy groceries" in output
    assert "Clean the house" in output

# Test that the file is cleared before each test
def test_clear_file():
    with open(TASKS_FILE, "a") as file:
        file.write("Some task\n")

    clear_file()  # Clear the tasks file

    # Check if the file is empty
    with open(TASKS_FILE, "r") as file:
        tasks = file.readlines()

    assert len(tasks) == 0  # The file should be empty after clearing
