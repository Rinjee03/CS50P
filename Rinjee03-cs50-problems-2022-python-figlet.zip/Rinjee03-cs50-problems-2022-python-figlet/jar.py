class Jar:
    # Initialize the cookie jar with a capacity and size (number of cookies inside)
    def __init__(self, capacity=12):
        # Capacity must be a non-negative integer
        if not isinstance(capacity, int) or capacity < 0:
            raise ValueError("Capacity must be a non-negative integer.")
        self._capacity = capacity  # Maximum number of cookies the jar can hold
        self._size = 0  # Current number of cookies in the jar

    # Represent the cookie jar as a string with the correct number of cookie emojis
    def __str__(self):
        return "🍪" * self._size

    # Add cookies to the jar
    def deposit(self, n):
        # Number of cookies to add must be a non-negative integer
        if not isinstance(n, int) or n < 0:
            raise ValueError("Number of cookies must be a non-negative integer.")
        # Ensure the jar does not exceed its capacity
        if self._size + n > self._capacity:
            raise ValueError("Exceeds capacity.")
        self._size += n  # Increase the number of cookies in the jar

    # Remove cookies from the jar
    def withdraw(self, n):
        # Number of cookies to remove must be a non-negative integer
        if not isinstance(n, int) or n < 0:
            raise ValueError("Number of cookies must be a non-negative integer.")
        # Ensure there are enough cookies to remove
        if n > self._size:
            raise ValueError("Not enough cookies in the jar.")
        self._size -= n  # Decrease the number of cookies in the jar

    # Return the capacity of the jar (maximum number of cookies it can hold)
    @property
    def capacity(self):
        return self._capacity

    # Return the current number of cookies in the jar
    @property
    def size(self):
        return self._size

