import re
import sys


def main():
    # Get user input and print the count of "um" occurrences
    print(count(input("Text: ")))


def count(s):
    """
    Counts the number of times 'um' appears in the text as a standalone word.
    Matches are case-insensitive and do not include 'um' as a substring of other words.
    """
    # Use a regular expression to match "um" as a whole word, case-insensitively
    # \b matches word boundaries
    matches = re.findall(r"\bum\b", s, re.IGNORECASE)
    return len(matches)


if __name__ == "__main__":
    main()
