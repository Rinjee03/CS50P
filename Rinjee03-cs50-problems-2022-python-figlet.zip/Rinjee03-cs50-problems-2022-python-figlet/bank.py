def main():
    #giving greet to customer
    g = input("Greeting : ")
    value_of_g = value(g)
    print(f"${value_of_g}")

def value(greeting):
    greeting = greeting.lower().strip()
    #checking if hello is in greet is or not
    if  "hello" in greeting:
        return 0


    #checking if greet start with letter "h" or not
    elif  "h" == greeting[0]:
        return 20



    #if greet neither include "hello" nor start with word "h"
    else:
        return 100


if __name__ == "__main__":
    main()
