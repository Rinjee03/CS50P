import sys
import csv

def main():
    # Check if the correct number of command-line arguments is provided
    if len(sys.argv) != 3:
        sys.exit("Usage: python scourgify.py input.csv output.csv")

    # Get the input and output file names from command-line arguments
    input_file = sys.argv[1]
    output_file = sys.argv[2]

    try:
        # Open the input CSV file for reading
        with open(input_file, "r") as infile:
            reader = csv.DictReader(infile)  # Read the file as a dictionary

            # Ensure the input file contains the required columns
            if "name" not in reader.fieldnames or "house" not in reader.fieldnames:
                sys.exit("Input file must contain 'name' and 'house' columns.")

            # Open the output CSV file for writing
            with open(output_file, "w", newline="") as outfile:
                # Define the columns for the output file
                fieldnames = ["first", "last", "house"]
                writer = csv.DictWriter(outfile, fieldnames=fieldnames)

                # Write the header row to the output file
                writer.writeheader()

                # Process each row from the input file
                for row in reader:
                    # Split the 'name' column into 'last' and 'first' names
                    last, first = row["name"].split(", ")

                    # Write the processed data to the output file
                    writer.writerow({"first": first, "last": last, "house": row["house"]})

    except FileNotFoundError:
        # Handle the case where the input file does not exist
        sys.exit(f"Could not read file '{input_file}'.")
    except Exception as e:
        # Handle any other unexpected errors
        sys.exit(f"An error occurred: {e}")

if __name__ == "__main__":
    # Run the main function
    main()
