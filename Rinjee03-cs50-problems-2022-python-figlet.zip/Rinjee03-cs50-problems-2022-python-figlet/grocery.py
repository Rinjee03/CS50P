food = {}

while True:
    try:
        # Asking user to input, treating the input as case insensitive
        item = input().strip().upper()

        if item in food:
            food[item] += 1
        else:
            food[item] = 1

    except EOFError:
        # Sorting and printing the food dictionary in a formatted manner
        for key in sorted(food.keys()):
            print(food[key], key)
        break

