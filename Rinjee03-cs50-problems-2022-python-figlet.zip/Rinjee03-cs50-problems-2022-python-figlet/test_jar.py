import pytest
from jar import Jar

# Test the initialization of the Jar class
def test_init():
    jar = Jar(10)
    assert jar.capacity == 10
    assert jar.size == 0

    with pytest.raises(ValueError):
        Jar(-1)

# Test the string representation of the jar
def test_str():
    jar = Jar()
    assert str(jar) == ""
    jar.deposit(3)
    assert str(jar) == "🍪🍪🍪"
    jar.deposit(2)
    assert str(jar) == "🍪🍪🍪🍪🍪"

# Test depositing cookies into the jar
def test_deposit():
    jar = Jar(5)
    jar.deposit(3)
    assert jar.size == 3

    with pytest.raises(ValueError):
        jar.deposit(3)  # Exceeds capacity

    with pytest.raises(ValueError):
        jar.deposit(-1)  # Invalid number of cookies

# Test withdrawing cookies from the jar
def test_withdraw():
    jar = Jar(5)
    jar.deposit(4)
    jar.withdraw(2)
    assert jar.size == 2

    with pytest.raises(ValueError):
        jar.withdraw(3)  # Not enough cookies in the jar

    with pytest.raises(ValueError):
        jar.withdraw(-1)  # Invalid number of cookies

# Test the capacity property
def test_capacity():
    jar = Jar(7)
    assert jar.capacity == 7

# Test the size property
def test_size():
    jar = Jar()
    assert jar.size == 0
    jar.deposit(4)
    assert jar.size == 4
