import validators


def main():
    # Prompt the user for an email address
    email = input("Email: ")
    # Validate the email and print the result
    if validate_email(email):
        print("Valid")
    else:
        print("Invalid")


def validate_email(email):
    """
    Validates the email address using the validators library.
    Returns True if the email is valid, False otherwise.
    """
    return validators.email(email)


if __name__ == "__main__":
    main()
