import inflect
import sys

# Create an inflect engine for handling proper grammar
p = inflect.engine()

# Initialize a list to store the names entered by the user
names = []

# Prompt the user for names until they input EOF (Ctrl+D on Linux/Mac, Ctrl+Z on Windows)
print("Enter names (press Ctrl+D to finish):")
try:
    while True:
        name = input()  # Read a name from the user
        names.append(name)  # Add the name to the list
except EOFError:
    pass  # Exit the loop when EOF is detected

# Join the names into a properly formatted phrase
# Using inflect's "join" method to handle commas and 'and'
formatted_names = p.join(names)

# Print the final output
print(f"Adieu, adieu, to {formatted_names}")
